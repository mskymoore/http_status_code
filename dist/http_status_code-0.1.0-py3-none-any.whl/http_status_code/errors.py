class CodeAlreadyExistException(Exception):
	pass
